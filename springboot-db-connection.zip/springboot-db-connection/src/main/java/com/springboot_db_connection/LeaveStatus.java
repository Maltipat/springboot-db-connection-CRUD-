package com.springboot_db_connection;

public enum LeaveStatus {
	PENDING, APPROVED, REJECTED
}
