package com.springboot_db_connection;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringbootDbConnectionApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringbootDbConnectionApplication.class, args);
	}

}
//* steps to clear url exception
//* Select project --right click on it--run as---select run configuration
//* select dependencies--select classpathentries
//* ---select advanced---select add folder--click on ok
//* --open your project--open src--open main
//* and select resources folder---click on ok --apply and run