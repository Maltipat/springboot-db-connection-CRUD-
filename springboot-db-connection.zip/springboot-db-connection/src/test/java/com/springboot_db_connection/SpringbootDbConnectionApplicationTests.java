package com.springboot_db_connection;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringbootDbConnectionApplicationTests {

	@Test
	void contextLoads() {
	}

}
